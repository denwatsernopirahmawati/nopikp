<?php 
include 'admin/koneksi.php'; 

//menampilkan data 
$query_data = "SELECT * FROM tb_spp ORDER BY id_spp ASC";
$rs_data = mysqli_query($koneksi, $query_data) or die(mysqli_error($koneksi));
 ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Grafik Pembayaran</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
</head>

<body>
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="alert alert-success">
                    <h1>Grafik Pembayaran</h1>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-6">
                <h3> Grafikk </h3>
                <div>
                    <canvas id="myChart"></canvas>
                </div>
            </div>
            <div class="col-6">
                <h3>  </h3>
                <p>
                    <?php 
                    $id_spp = "";
                    $siswa_id = "";
                    foreach($rs_data as $row) { 
                    $id_spp .= $row['id_spp'] . ",";
                    $siswa_id .= $row['siswa_id'] . ",";
                     } ?>
                    <?php $id_spp = substr($id_spp, 0, -1); 
                    $siswa_id = substr($siswa_id, 0, -1);
                   
                    ?>
                </p>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
    const ctx = document.getElementById('myChart');

    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni' , 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'],
            datasets: [{
                    label: '#tahun 2023',
                    data: [<?= $id_spp; ?>],
                    borderWidth: 1
                },
                {
                    label: '#tahun 2024',
                    data: [<?= $siswa_id; ?>],
                    borderWidth: 1
                }
            ]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
    </script>
</body>
</html>