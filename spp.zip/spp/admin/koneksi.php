<?php 
$host = "localhost";
$user = "root";
$pass = "";
$db = "dbspp";

$koneksi = new mysqli($host, $user, $pass, $db);

$title = "Pembayaran SPP/Syahriyah 
Nurul Hidayah Malabar"

?>